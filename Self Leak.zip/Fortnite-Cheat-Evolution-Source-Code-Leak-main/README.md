# Fortnite-Cheat-Evolution-Source-Code-Leak
Micca is the biggest skid in the community rn lmao, scamming people to get some money to buy a source or pay someone to make him a cheat. He never changes lmao.
Never trust dis guy.

Thanks to !mox#1337 for sending it.

Injector: https://volticcheetos.tk

If you dont know how to fix this, https://github.com/Kynch9667/Fortnite-Nuclear-Cheat-Src-Fixed here is the oiginal source they pasted, this wont give errors when compiling
